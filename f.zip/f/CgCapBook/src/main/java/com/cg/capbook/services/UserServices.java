package com.cg.capbook.services;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.cg.capbook.beans.FriendRequest;
import com.cg.capbook.beans.FriendsList;
import com.cg.capbook.beans.Message;
import com.cg.capbook.beans.Post;
import com.cg.capbook.beans.User;
import com.cg.capbook.exceptions.EmptyFriendListException;
import com.cg.capbook.exceptions.FriendRequestException;
import com.cg.capbook.exceptions.IncorrectPasswordException;
import com.cg.capbook.exceptions.PostNotFoundException;
import com.cg.capbook.exceptions.UserNotFoundException;
public interface UserServices {
	//SignIn and SignUp
	User acceptUserDetails(User user) throws NoSuchAlgorithmException, UserNotFoundException, IncorrectPasswordException;
	User getUserDetails(String emailId,String password) throws UserNotFoundException, IncorrectPasswordException, NoSuchAlgorithmException;
	public ArrayList<User> getAllUsers();
	//Friend Request Related
	FriendRequest sendFriendRequest(String senderEmail,String receiverEmail) throws UserNotFoundException, FriendRequestException;
	FriendRequest acceptFriendRequest(String senderEmail,String receiverEmail) throws UserNotFoundException, FriendRequestException;
	List<FriendsList> getUserFriendList(String emailId) throws UserNotFoundException, EmptyFriendListException;
	FriendRequest deleteFriendRequest(String senderEmail,String receiverEmail) throws UserNotFoundException,FriendRequestException;
	List<FriendRequest> getNotifications(String emailid) throws UserNotFoundException ;
	User getUserDetailsByEmail(String emailid) throws UserNotFoundException;
	ArrayList<FriendRequest> getAllFriendRequestSent(String receiverEmail) throws UserNotFoundException, EmptyFriendListException;
	ArrayList<FriendRequest> getAllFriendRequestReceived(String senderEmail)
			throws UserNotFoundException, EmptyFriendListException;
	//Password Related
	User changePassword(String emailId,String oldPassword,String newPassword,String confirmNewPassword) throws UserNotFoundException, IncorrectPasswordException, NoSuchAlgorithmException;
	User forgotPassword(String emailId,String securityQuestion,String securityAnswer,String newPassword) throws UserNotFoundException, IncorrectPasswordException, NoSuchAlgorithmException;
	//Profile Picture Related
	User insertProfilePic(byte[] profilePic);
	byte[] fetchProfilePic();
	//Message Related
	Message sendMessage(String senderEmail,String receiverEmail,String textMessage) throws UserNotFoundException;
	ArrayList<Message> getSentMessage(String senderEmail) throws UserNotFoundException;
	ArrayList<Message> getReceivedMessage(String receiverEmail) throws UserNotFoundException;
	//Friend Search
	List<User> findFriends(String emailId) throws UserNotFoundException, EmptyFriendListException;
	//Update Profile
	User updateProfile(User user);
	//Post Related
	Post sendPost( String message) throws UserNotFoundException, EmptyFriendListException;
	List<Post> getAllPosts() throws UserNotFoundException, EmptyFriendListException;
	List<Post> myPosts(String emailId) throws UserNotFoundException;
}