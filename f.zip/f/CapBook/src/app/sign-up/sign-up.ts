export interface SignUp {
    firstName: string;
    lastName: string;
    emailid: string;
    gender: string;
    dateOfBirth: string;
    phoneNumber:number;
    password:string;
    confirmPassword:string;
    securityQuestion:string;
    securityAnswer:string;
    city:string
    state:string
    country:string
    collegeName:string
    relationShipStatus:string
}
