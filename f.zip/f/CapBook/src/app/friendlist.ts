export interface Friendlist {
    senderEmail:string;
    receiverEmail:string;
    listId:number;
    fullName:string;
}
