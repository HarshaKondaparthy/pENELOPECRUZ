import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CapbookserviceService } from '../services/capbookservice.service';
import { SignUp } from '../sign-up/sign-up';

@Component({
  selector: 'app-updateprofile',
  templateUrl: './updateprofile.component.html',
  styleUrls: ['./updateprofile.component.css']
})
export class UpdateprofileComponent implements OnInit {
  _emailid:string
  _relationShipStatus:string
  _city:string
  _state:string
  _country:string
  _collegeName:string
  signUp:SignUp
  signUp1:SignUp
  message:string
  get emailid():string{
    return this._emailid;
  }
  set emailid(value: string){
    this._emailid=value;
  }
  get relationShipStatus():string{
    return this._relationShipStatus;
  }
  set relationShipStatus(value: string){
    this._relationShipStatus=value;
  }
  get city():string{
    return this._city;
  }
  set city(value: string){
    this._city=value;
  }
  get state():string{
    return this._state;
  }
  set state(value: string){
    this._state=value;
  }
  get country():string{
    return this._country;
  }
  set country(value: string){
    this._country=value;
  }
  get collegeName():string{
    return this._collegeName;
  }
  set collegeName(value: string){
    this._collegeName=value;
  }

  constructor(private route:ActivatedRoute,private router:Router,private capbookservice:CapbookserviceService) { }

  ngOnInit() {
    this.signUp= JSON.parse(sessionStorage.getItem('signUp'));
  }
  onSubmit(signUp2:SignUp){
    this.capbookservice.updateProfile(signUp2).subscribe(
      message=>{
        this.message=message;
      }
    )
    this.router.navigate(['/profile2',this.signUp.emailid]);
  }

}
