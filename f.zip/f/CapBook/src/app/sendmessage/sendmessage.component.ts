import { Component, OnInit } from '@angular/core';
import { SignUp } from '../sign-up/sign-up';
import { ActivatedRoute, Router } from '@angular/router';
import { CapbookserviceService } from '../services/capbookservice.service';
import { Message } from '../message';

@Component({
  selector: 'app-sendmessage',
  templateUrl: './sendmessage.component.html',
  styleUrls: ['./sendmessage.component.css']
})
export class SendmessageComponent implements OnInit {
  signUp:SignUp
  _receivermail:string
  _receiverEmail:string
  _textMessage:string
  message:Message
  get textMessage():string{
    return this._textMessage;
  }
  set textMessage(value: string){
    this._textMessage=value;
  }
  constructor(private route:ActivatedRoute,private router:Router,private capbookservice:CapbookserviceService) { }

  ngOnInit() {
    this.signUp= JSON.parse(sessionStorage.getItem('signUp'));
    this._receivermail=this.route.snapshot.paramMap.get('senderEmail');
    this._receiverEmail=this._receivermail;
  }
  onSubmit(){
    this.capbookservice.sendMessage(this.signUp.emailid,this._receiverEmail,this._textMessage).subscribe(
      message=>{
        this.message=message;
      }
    )
  }

}
