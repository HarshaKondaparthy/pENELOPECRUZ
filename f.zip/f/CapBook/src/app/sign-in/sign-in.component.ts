import { Component, OnInit } from '@angular/core';

import { CapbookserviceService } from '../services/capbookservice.service';
import { Router } from '@angular/router';
import { SignUp } from '../sign-up/sign-up';

@Component({
  selector: 'app-sign-in',
  templateUrl: './sign-in.component.html',
  styleUrls: ['./sign-in.component.css']
})
export class SignInComponent implements OnInit {
  errorMessage:string;
  signUp:SignUp;
  signup:SignUp
  _emailid:string;
  _password:string;
  message:string
  constructor(private router:Router,private capbookService:CapbookserviceService ) { }
  get emailid():string{
    return this._emailid;
  }
  set emailid(value: string){
    this._emailid=value;
  }
  get password():string{
    return this._password;
  }
  set password(value: string){
    this._password=value;
  }

  ngOnInit() {
    this.capbookService.getUserDetailsByEmail(this._emailid).subscribe(
      signup=>{
        this.signup=signup;
      
      },
      errorMessage=>{
       this.errorMessage = errorMessage;
     })
  }
  onSubmit(){
  
    this.capbookService.getUserDetails(this._emailid,this._password).subscribe(
     signUp=>{
       this.signUp=signUp;
       
 sessionStorage.setItem('signUp', JSON.stringify(signUp));
 //user1 = JSON.parse(sessionStorage.getItem('user'));
 if(signUp){
  this.router.navigate(['/profile']);
 }
  
     },
     errorMessage=>{
      this.errorMessage = 'Incorrect Credentials';
    })
  
    this.router.navigate(['/signIn']);
     
    }

}
