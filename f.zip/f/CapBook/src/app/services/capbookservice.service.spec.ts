import { TestBed } from '@angular/core/testing';

import { CapbookserviceService } from './capbookservice.service';

describe('CapbookserviceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CapbookserviceService = TestBed.get(CapbookserviceService);
    expect(service).toBeTruthy();
  });
});
