import { Component, OnInit } from '@angular/core';
import { SignUp } from '../sign-up/sign-up';
import { ActivatedRoute, Router } from '@angular/router';
import { CapbookserviceService } from '../services/capbookservice.service';

@Component({
  selector: 'app-profile2',
  templateUrl: './profile2.component.html',
  styleUrls: ['./profile2.component.css']
})
export class Profile2Component implements OnInit {
  signUp:SignUp
  email:string
  emailid:string
  signUp1:SignUp
  fileToUpload: File = null;
  constructor(private route:ActivatedRoute , private router:Router, private capbookservice:CapbookserviceService ) { }

  ngOnInit() {
    
    this.email= this.route.snapshot.paramMap.get( 'emailid' );
    this.emailid = this.email;  
    this.capbookservice.getUserDetailsByEmail(this.emailid).subscribe(
      signUp=>{
        this.signUp=signUp;
      }
    )
  }
  handleFileInput(files: FileList) {
    this.fileToUpload = files.item(0);
    this.uploadFileToActivity();
  }
  
  uploadFileToActivity() {
  console.log("in upload");
  this.capbookservice.postFile(this.fileToUpload).subscribe(
   
    data => {
    console.log("success")
    },
     error => {
      console.log(error);
    });
  }
  }


