import { Component, OnInit } from '@angular/core';
import { SignUp } from '../sign-up/sign-up';
import { CapbookserviceService } from '../services/capbookservice.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Friendlist } from '../friendlist';

@Component({
  selector: 'app-friendlist',
  templateUrl: './friendlist.component.html',
  styleUrls: ['./friendlist.component.css']
})
export class FriendlistComponent implements OnInit {
  friendsListTitle:string='Friends List';
  error:string
  email:string
  emailid:string
  signUp:SignUp
  constructor(private route:ActivatedRoute,private router:Router,private capBookSerivce:CapbookserviceService){
  }
  friendsList:Friendlist[];
  friends:Friendlist[];
  ngOnInit() {
    this.signUp= JSON.parse(sessionStorage.getItem('signUp'));
    this.capBookSerivce.getUserFriendList(this.signUp.emailid).subscribe(
      tempFriends=>{
        this.friends=tempFriends;
        this.friendsList=this.friends;
      },
      error=>{
        this.error=error;
      }
    );
  }
  public navigateBack(): void{
    this.router.navigate(['/profile'])
  }
}
