import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CapbookserviceService } from '../services/capbookservice.service';

@Component({
  selector: 'app-rejectfriend',
  templateUrl: './rejectfriend.component.html',
  styleUrls: ['./rejectfriend.component.css']
})
export class RejectfriendComponent implements OnInit {

  senderEmail:string
  senderEmailid:string
  receiverEmail:string
  receiverEmailid:string
  errorMessage:string
  message:string="Request Deleted"
  constructor(private route:ActivatedRoute,private router:Router,private capbookservice:CapbookserviceService) { }

  ngOnInit() {
    this.senderEmail=this.route.snapshot.paramMap.get('senderEmail');
    this.senderEmailid=this.senderEmail;
    this.receiverEmail=this.route.snapshot.paramMap.get('receiverEmail');
    this.receiverEmailid=this.receiverEmail;
    this.capbookservice.deleteRequest(this.senderEmailid,this.receiverEmailid).subscribe(
      message=>{
      this.message=message;
      },
      errorMessage=>{
        this.errorMessage=errorMessage;
      }
    );
  }
}
